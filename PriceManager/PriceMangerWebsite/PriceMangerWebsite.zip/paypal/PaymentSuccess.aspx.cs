﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using PriceManagerDAL;
using System.IO;
using System.Net;
using System.Text;
using System.Globalization;
using System.Text.RegularExpressions;

public partial class paypal_PaymentSuccess : Base
{
    protected void Page_Load(object sender, EventArgs e)
    {


    }

    
}



