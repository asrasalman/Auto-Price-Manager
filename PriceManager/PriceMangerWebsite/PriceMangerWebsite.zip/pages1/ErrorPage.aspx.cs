﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using PriceManagerDAL;

public partial class site_Activation : Base
{
    public string NV = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {

        

    }

  



}