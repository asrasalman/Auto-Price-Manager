﻿function InitializePricing() {
    GetPricingItems();
    $(".btnEdit").live("click", function () { EditItem(this) });
    $(".select-select2").each(function () { $(this).select2(); })
    $("#btnSearch").live("click", function () { GetSearchResults() });
    $("#btnRevise").live("click", function () { ReviseFilter() });
    $("#btnSave").live("click", function () { SavePricingDetails() });
    $("#btnMainSearch").live("click", function () { GetPricingItems(false); });
    $("#btnReloadListing").live("click", function () { GetPricingItems(true); });
}


function EditItem(obj) {
    obj = $(obj);
    var itemID = obj.closest("tr").find(".spnItemID").text();
    var itemCode = obj.closest("tr").find(".hfItemCode").val();
    $("#hfItemID").val(itemID);
    $("#hfItemCode").val(itemCode);
    XHR_GetPricingItems(itemCode, null, null, null, null, null, function (result) {
        if (result) {
            var items = JSON.parse(result);
            ResetControls("[data-column]");
            BindData(items[0], "[data-column]");
////            $("#chkAutomate").switchButton({
////                labels_placement: "right",
////                width: 75,
////                height: 20,
////                button_width: 35
////            });
            MyModal(".divFiltersModal", 'Price Automation : ' + itemID, 800, 'auto');
        }

    }, null)
    
}
function ReviseFilter() {
    var body = $('#ulResults');
    body.empty();
    $(".divSearchResults, #btnRevise").hide();
    $(".divPricingInputs, #btnSearch").fadeIn();
}
function GetSearchResults(obj) {
    obj = $(obj);
    var keyword = $("#txtKeywords").val();
    var ItemID = $("#hfItemID").val();
    var tokenJSON = $(".hfTokenJSON").val();
    
    if ($.trim(keyword) == '') {
        ShowInfo("Search query can not be empty.")
        return false;
    }
    var pageSize = 20;
    var filter = CreateObject("[data-filter]");
    if (filter) {
        $(".divPricingInputs, #btnSearch").hide();
        $(".divSearchResults, #btnRevise").fadeIn();
        $(".divSearchResults").addClass("loading");
        var body = $('#ulResults');
        body.empty();
        XHR_GetProductRank(JSON.stringify(filter), pageSize, tokenJSON, function (result) {
            $(".divSearchResults").removeClass("loading");
            if (result) {
                var data = JSON.parse(result);
                var li = $('#searchTemplate').tmpl(data);
                body.append(li).hide().fadeIn();
                $('.hfMyProduct[value="true"]').closest('li').addClass('myProduct');
                $(obj).prop('disabled', false);
            }
            else {
                
                var notFound = "<li class='resultItem'><strong>No item(s) Found. Please revise your search filters.</strong></li>"
                body.append(notFound).hide().fadeIn();
            }

        }, null);
    }
    return false;
}

function GetPricingItems(reload) {
    var account = $("#ddlEbayAccount").val();
    var category = $("#ddlEbayCategory").val();
    var searchFeild = $("#ddlSearchFeild").val();
    var searchValue = $("#txtSearchValue").val();
    $(".loadingContainer").parent().show();
    XHR_GetPricingItems(null, account, category, searchFeild, searchValue, reload, function (result) {
        $(".loadingContainer").parent().hide();
        if (result) {
            var items = JSON.parse(result);
            if (items.length > 0) {
                $('#tblPricingItems tbody').empty();

                $('#pricingItemTemplate').tmpl(items).appendTo('#tblPricingItems tbody');

                setupTablesorter();

                $('input.numeric').numeric();
            }
            else {
                var rows = "<tr><td colspan='12'>No items found.</td></tr>";
                $('#tblPricingItems tbody').empty().append(rows);
            }
        }
        else {
            var rows = "<tr><td colspan='12'>No items found.</td></tr>";
            $('#tblPricingItems tbody').empty().append(rows);

        }


    }, null)
}



function setupTablesorter() {
    $('table.tablesorter').each(function (i, e) {
        var myHeaders = {}
        $(this).find('th.nosort').each(function (i, e) {
            myHeaders[$(this).index()] = { sorter: false };
        });
        $(this).tablesorter({ widgets: ['zebra'], headers: myHeaders });
        $("#tablePagination").remove();
        $(this).oneSimpleTablePagination({ topNav: false });
        $("#tablePagination").find("a").removeClass("button").addClass("button1");
        $("#tablePagination_currPage").addClass("numeric");
    });
    
}

function SavePricingDetails() {
    var editedData = CreateObject("[data-column]");
    if (editedData) {
        var errorHtml = "";
        var isValidated = true;
        if (editedData.Is_Automated == true) {
            if (editedData.Keywords == null) {
                errorHtml += "<li>Please enter search query</li>";
                isValidated = false;
            }
            if (editedData.Algo == null) {
                errorHtml += "<li>Please select algorithm</li>";
                isValidated = false;
            }
            if (editedData.Floor_Price == null) {
                errorHtml += "<li>Please enter floor price</li>";
                isValidated = false;
            }
            if (editedData.Ceiling_Price == null) {
                errorHtml += "<li>Please enter ceiling price</li>";
                isValidated = false;
            }
            if (editedData.Less_To_Lowest_Price == null) {
                errorHtml += "<li>Please enter less to lowest price</li>";
                isValidated = false;
            }
            if (isValidated) {
                if (parseFloat(editedData.Floor_Price) > parseFloat(editedData.Ceiling_Price)) {
                    errorHtml += "<li>Floor price should be less than equals to ceiling price</li>";
                    isValidated = false;
                }
            }
        }

        if (isValidated) {
            $("#ulErrors").empty();
            $(".errorbox").hide();
            $(".loadingContainer").parent().show();
            XHR_UpdatePricingItems(JSON.stringify(editedData), function (result) {
                if (result) {
                    var items = JSON.parse(result);
                    var tr = $(".hfItemCode[value=" + items[0].Item_Code + "]").closest("tr");
                    var itemRow = $('#pricingItemTemplate').tmpl(items);
                    tr.html(itemRow.html());
                    $(".loadingContainer").parent().hide();
                    ShowInfo("Updated successfully.", "green");
                }
            }, null);
        }
        else {
            $("#ulErrors").html(errorHtml)
            $(".errorbox").fadeIn();
        }
    }
    else
        ShowInfo("There is no records found to be updated.");
}



function XHR_GetPricingItems(itemCode, account, category, searchFeild, searchValue, isReload, OnSuccess, OnError) {
    var service = new GeneralServices.GeneralSvc();
    service.GetPricingItems(itemCode, account, category, searchFeild, searchValue, isReload, OnSuccess, OnErrorGeneral, null);
}

function XHR_UpdatePricingItems(updatedData, OnSuccess, OnError) {
    
    var service = new GeneralServices.GeneralSvc();
    service.UpdatePricingItems(updatedData, OnSuccess, OnErrorGeneral, null);
}

function XHR_GetProductRank(filter, pageSize, tokenJSON, OnSuccess, OnError) {
    var service = new GeneralServices.GeneralSvc();
    service.GetProductRank(filter, pageSize, tokenJSON, null, OnSuccess, OnErrorGeneral, null);
}

function OnErrorGeneral(alert) {
    $(".loadingContainer").parent().hide();
    ShowInfo("Something went wrong! Please try later.", "red")
}

function ShowInfo(information, color) {
    $('.infoContainer').text(information);

    if (color == 'green')
        $('.infoContainer').addClass('infoContainerGreen');
    else if (color == 'red')
        $('.infoContainer').addClass('infoContainerRed');

    $('.infoContainer').show('slide', { direction: 'right' }, 500);
    setTimeout(function () {
        $('.infoContainer').hide('slide', { direction: 'right' }, 700, function () {
            $('.infoContainer').removeClass('infoContainerGreen').removeClass('infoContainerRed');
        });
    }, 5000);
}

function CreateObject(dataAttr) {
    var elements = $("input" + dataAttr + ", textarea" + dataAttr + ", select" + dataAttr + " ,a" + dataAttr + " ,span" + dataAttr +  " ,img" + dataAttr);
    var param = new Object();
    elements.each(function () {
        var column = this.getAttribute('data-column');
        if (this.getAttribute('type') == 'checkbox') {
            param[column] = $(this).is(":checked");
        }
        else if ($(this).is(".select-select2")) {
            var selectValues = $(this).select2().val();
            var csv = "";
            if (selectValues) {
                for (var i = 0; i < selectValues.length; i++) {
                    csv += "," + selectValues[i];
                }
                if (csv != "")
                    csv = csv.substring(1, csv.length);
            }
            param[column] = csv;
        }
        else if ($(this).is(".anchor")) {
            param[column] = $(this).attr("href");
        }
        else if ($(this).is(".image")) {
            param[column] = $(this).attr("src");
        }
        else if ($(this).is(".span")) {
            param[column] = $(this).text();
        }
        else {
            var value = $(this).val();
            if (value != "")
                param[column] = value;
            else
                param[column] = null;
        }
    });
    return param;
}

function BindData(jdata, dataAttr) {
    var elements = $("input" + dataAttr + ", textarea" + dataAttr + ", select" + dataAttr + " ,a" + dataAttr + " ,span" + dataAttr + " ,img" + dataAttr);
    elements.each(function () {
        var column = this.getAttribute('data-column');
        if (jdata[column]) {
            if (this.getAttribute('type') == 'checkbox') {
                $(this).attr("checked", jdata[column]);
            }
            else if ($(this).is(".select-select2")) {
                var selectValues = jdata[column].split(',');
                $(this).val(selectValues).select2();
            }
            else if ($(this).is(".select-normal")) {
                $(this).val(jdata[column]);
            }
            else if ($(this).is(".anchor")) {
                $(this).attr("href", jdata[column]);
            }
            else if ($(this).is(".image")) {
                $(this).attr("src", jdata[column]);
            }
            else if ($(this).is(".span")) {
                $(this).text(jdata[column]);
            }
            else {
                $(this).val(jdata[column]);
            }
        }
    });

}

function ResetControls(dataAttr) {
   
    ReviseFilter();
    var elements = $("input" + dataAttr + ", textarea" + dataAttr + ", select" + dataAttr + " ,a" + dataAttr + " ,span" + dataAttr + " ,img" + dataAttr);
    $("#ulErrors").empty();
    $(".errorbox").hide();
    elements.each(function () {
        if (this.getAttribute('type') == 'checkbox') {
            $(this).attr("checked", false);
        }
        else if ($(this).is(".select-select2")) {
            $(this).val([]).select2();
        }
        else if ($(this).is(".select-normal")) {
            $(this).val("");
        }
        else if ($(this).is(".anchor")) {
            $(this).attr("href", "");
        }
        else if ($(this).is(".image")) {
            $(this).attr("src", "");
        }
        else if ($(this).is(".span")) {
            $(this).text("");
        }
        else {
            $(this).val("");
        }
    });
    $("#chkFixedPrice, #chkLocationAU").prop("checked", true);
}
function formatPrice(value) {
    if (isNaN(parseFloat(value)))
        return "";
    else
        return parseFloat(value).toFixed(2);
}
function MyModal(id, title, width, height) {
    var mydiv = $(id);
    mydiv.dialog(
             {
                 autoOpen: false,
                 modal: true,
                 resizable: false,
                 title: title,
                 width: width,
                 height: height,
                 closeOnEscape: true
             });
    $('.ui-dialog').appendTo($('form:first'));
    mydiv.dialog('open');
    return false;
}
function MyModalClose(id) {
    var mydiv = $(id);
    mydiv.dialog("close");
}


